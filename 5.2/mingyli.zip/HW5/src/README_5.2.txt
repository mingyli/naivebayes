This is the README file for HW 5.2. To run the starter code as it is, press 
the "Run" button (looks like a white triangle in a green circle). It just 
won't do anything yet.

When you're all done, fill out this file with instructions on how to run your 
code if you have any special instructions, constants that need to be set, etc.
Also include the results of your algorithm on each of the data sets.

Instructions:
Run LogisticRegression.java. Follow the prompts provided by the console.

simple
Class 0: tested 2, correctly classified 2
Class 1: tested 2, correctly classified 2
Overall: tested 4, correctly classified 4
Accuracy: 1.000000


vote
Class 0: tested 52, correctly classified 51
Class 1: tested 83, correctly classified 83
Overall: tested 135, correctly classified 134
Accuracy: 0.992593


heart
learning rate: .00000001
Class 0: tested 15, correctly classified 7
Class 1: tested 172, correctly classified 168
Overall: tested 187, correctly classified 175
Accuracy: 0.935829

