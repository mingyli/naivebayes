This is the README file for HW 5.1. To run the starter code as it is, press 
the "Run" button (looks like a white triangle in a green circle). It just 
won't do anything yet.

When you're all done, fill out this file with instructions on how to run your 
code if you have any special instructions, constants that need to be set, etc.
Also include the results of your algorithm on each of the data sets.