/* CS109 HW5.2: Logistic Regression
 * --------------------------------
 * This file contains starter code for your logistic regression classifier. 
 * Your job is to read in the data file and implement the logistic regression 
 * algorithm.
 *  
 * Note: This starter code is written without the Stanford libraries. If you 
 * took CS106A and want that style of starter code, download the other Java
 * starter code.
 */

public class LogisticRegression {
	
	public void run()
	{
		
	}

	public static void main(String[] args) {
		//TODO: Fill this out!
		LogisticRegression l = new LogisticRegression();
		l.run();
	}

}
