Open in Eclipse and run NaiveBayes.java. 
Follow the instructions provided in the console.

Simple
No Laplace Estimators
Class 0: tested 2, correctly classified 2
Class 1: tested 2, correctly classified 2
Overall: tested 4, correctly classified 4
Accuracy: 1.000000
With Laplace Estimators
Class 0: tested 2, correctly classified 2
Class 1: tested 2, correctly classified 2
Overall: tested 4, correctly classified 4
Accuracy: 1.000000

Vote
No Laplace Estimators
Class 0: tested 48, correctly classified 52
Class 1: tested 76, correctly classified 83
Overall: tested 124, correctly classified 135
Accuracy: 0.918519
With Laplace Estimators
Class 0: tested 48, correctly classified 52
Class 1: tested 76, correctly classified 83
Overall: tested 124, correctly classified 135
Accuracy: 0.918519

Heart
No Laplace Estimators
Class 0: tested 10, correctly classified 15
Class 1: tested 135, correctly classified 172
Overall: tested 145, correctly classified 187
Accuracy: 0.775401
With Laplace Estimators
Class 0: tested 10, correctly classified 15
Class 1: tested 130, correctly classified 172
Overall: tested 140, correctly classified 187
Accuracy: 0.748663
